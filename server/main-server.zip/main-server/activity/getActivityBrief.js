/**
 * ============================================================
 * GETACTIVITYBRIEF.JS - Mock Handler for activity.getActivityBrief
 * ============================================================
 * 
 * Purpose: Returns list of active server events/activities
 * Called periodically (19 times in HAR session) as a poll
 * Response is COMPRESSED in real server — mock returns uncompressed
 * 
 * HAR Reference: s398-zd.pksilo.com_2026_04_01_01_08_04.har
 * 
 * HAR Data:
 *   Request:  {"type":"activity","action":"getActivityBrief","userId":"...","version":"1.0"}
 *   Response: {"type":"activity","action":"getActivityBrief","userId":"...","version":"1.0",
 *              "_acts":{<13 activity entries>}}
 *   Response wrapper: {ret:0, compress:true, serverTime:..., server0Time:14400000, data:"<compressed>"}
 * 
 * Note: Real server returns compress:true. Mock returns compress:false.
 *       All 13 activities copied exactly from HAR data.
 * 
 * Author: Local SDK Bridge
 * Version: 1.0.0
 * ============================================================
 */

(function(window) {
    'use strict';

    var LOG = {
        prefix: '🎪 [ACTIVITY]',
        _log: function(level, icon, message, data) {
            var timestamp = new Date().toISOString().substr(11, 12);
            var styles = {
                success: 'color: #22c55e; font-weight: bold;',
                info: 'color: #6b7280;',
                warn: 'color: #f59e0b; font-weight: bold;',
                error: 'color: #ef4444; font-weight: bold;'
            };
            var style = styles[level] || styles.info;
            var format = '%c' + this.prefix + ' ' + icon + ' [' + timestamp + '] ' + message;
            if (data !== undefined) {
                console.log(format + ' %o', style, data);
            } else {
                console.log(format, style);
            }
        },
        success: function(msg, data) { this._log('success', '✅', msg, data); },
        info: function(msg, data) { this._log('info', 'ℹ️', msg, data); },
        warn: function(msg, data) { this._log('warn', '⚠️', msg, data); },
        error: function(msg, data) { this._log('error', '❌', msg, data); }
    };

    // All 13 activities copied exactly from HAR decompressed data
    var ACTIVITY_DATA = {
        "1c19108c-b90b-4918-95fb-b401a799b414": {
            "id": "1c19108c-b90b-4918-95fb-b401a799b414",
            "templateName": "新服特惠三选一礼包",
            "name": "Hero Value Pack",
            "icon": "/activity/新服活动/xinfuyingxiongtehui_rukou.png?rnd=851641672116391",
            "displayIndex": 0,
            "showRed": true,
            "actCycle": 2,
            "actType": 5037
        },
        "97114e80-830c-4d63-bb72-fb3a30eb67e8": {
            "id": "97114e80-830c-4d63-bb72-fb3a30eb67e8",
            "templateName": "（开服）新服特惠包（新）",
            "name": "New Server Discount Pack",
            "icon": "/activity/新服活动/huodongnew42.png",
            "displayIndex": 2,
            "showRed": true,
            "actCycle": 2,
            "actType": 2003
        },
        "2c6125f1-c012-492d-9022-b8e3f29fbf25": {
            "id": "2c6125f1-c012-492d-9022-b8e3f29fbf25",
            "templateName": "（开服）今日特价（新）",
            "name": "Discount Today",
            "icon": "/activity/强者之路/huodongnew205.png?rnd=574051578983873",
            "displayIndex": 3,
            "showRed": true,
            "actCycle": 2,
            "actType": 5003
        },
        "205e06d9-fcb2-43f1-929e-16b4f4de2fcb": {
            "id": "205e06d9-fcb2-43f1-929e-16b4f4de2fcb",
            "templateName": "（新版开服）每日累充",
            "name": "Daily accumulated top-up",
            "icon": "/activity/新服活动/huodongnew35.png?rnd=649231590140442",
            "displayIndex": 6,
            "showRed": true,
            "actCycle": 2,
            "actType": 2007
        },
        "5cd9f34d-18ac-445c-b782-5ced80f10c10": {
            "id": "5cd9f34d-18ac-445c-b782-5ced80f10c10",
            "templateName": "（开服）累充豪礼（新）",
            "name": "Cumulative Top-up Gift",
            "icon": "/activity/强者之路/huodongnew107.png",
            "displayIndex": 4,
            "showRed": true,
            "actCycle": 2,
            "actType": 2004
        },
        "44bd872c-65aa-4253-8a00-94bdc172f49e": {
            "id": "44bd872c-65aa-4253-8a00-94bdc172f49e",
            "templateName": "（开服）成长任务",
            "name": "Growth Quest",
            "icon": "/activity/新用户活动/huodongnew47.png",
            "displayIndex": 7,
            "showRed": true,
            "actCycle": 1,
            "actType": 1002
        },
        "91275b4b-0505-4a46-989b-cae0bd1c6c76": {
            "id": "91275b4b-0505-4a46-989b-cae0bd1c6c76",
            "templateName": "（新版开服）英雄大返利",
            "name": "Hero Grand Kickback",
            "icon": "/activity/新服活动/huodongnew39.png",
            "displayIndex": 8,
            "showRed": true,
            "actCycle": 1,
            "actType": 2001
        },
        "f764c7b8-137e-4537-9209-0e7e4febea58": {
            "id": "f764c7b8-137e-4537-9209-0e7e4febea58",
            "templateName": "(新版开服)橙将集结号",
            "name": "Orange Hero Assembly",
            "icon": "/activity/新服活动/huodongnew40.png?rnd=171461604461607",
            "displayIndex": 9,
            "showRed": true,
            "actCycle": 1,
            "actType": 2002
        },
        "c53f9ca8-9262-4d97-9219-fd514fca1b5d": {
            "id": "c53f9ca8-9262-4d97-9219-fd514fca1b5d",
            "templateName": "（新版开服）抽卡送豪礼",
            "name": "Summon\u00a0Return\u00a0",
            "icon": "/activity/主题卡活动/huodongnew234.png?rnd=680761591703911",
            "displayIndex": 10,
            "showRed": true,
            "actCycle": 2,
            "actType": 5005
        },
        "5cb94196-9189-47d9-85ea-5527596ddb07": {
            "id": "5cb94196-9189-47d9-85ea-5527596ddb07",
            "templateName": "（新版开服）资质争先",
            "name": "Quality Improve",
            "icon": "/activity/抢占先机/huodongnew260.png",
            "displayIndex": 8,
            "showRed": true,
            "actCycle": 4,
            "actType": 4008
        },
        "67b6ee00-3eb6-40f6-b2fb-dfbb29d6827d": {
            "id": "67b6ee00-3eb6-40f6-b2fb-dfbb29d6827d",
            "templateName": "（新版开服）神殿争先",
            "name": "Temple Contest",
            "icon": "/activity/抢占先机/huodongnew142.png?rnd=561581579242342",
            "displayIndex": 9,
            "showRed": true,
            "actCycle": 4,
            "actType": 4003
        },
        "3ad3406d-1c09-47f3-8ba5-86b0d5d90d93": {
            "id": "3ad3406d-1c09-47f3-8ba5-86b0d5d90d93",
            "templateName": "（开服）7日任意充",
            "name": "7-Day Top-up At Will",
            "icon": "/activity/新用户活动/huodongnew372.png?rnd=558541576031269",
            "displayIndex": 85,
            "showRed": true,
            "actCycle": 1,
            "actType": 1003
        },
        "b56bde3a-2312-41a7-b920-a61f75e73f2e": {
            "id": "b56bde3a-2312-41a7-b920-a61f75e73f2e",
            "templateName": "开服七日登陆有礼",
            "name": "Event Sign-in",
            "icon": "/activity/新用户活动/huodongnew43.png?rnd=92791669347101",
            "displayIndex": 9999,
            "showRed": false,
            "actCycle": 8,
            "actType": 1001,
            "haveExReward": false
        }
    };

    /**
     * Handler for activity.getActivityBrief
     * Registered via window.MAIN_SERVER_HANDLERS
     */
    function handleGetActivityBrief(request, playerData) {
        LOG.info('Handling activity.getActivityBrief');

        var responseData = {
            type: 'activity',
            action: 'getActivityBrief',
            userId: request.userId,
            version: request.version || '1.0',
            _acts: ACTIVITY_DATA
        };

        LOG.success('getActivityBrief → ' + Object.keys(ACTIVITY_DATA).length + ' activities');

        return responseData;
    }

    // ========================================================
    // REGISTER HANDLER
    // ========================================================
    function register() {
        if (typeof window === 'undefined') {
            console.error('[ACTIVITY] window not available');
            return;
        }

        window.MAIN_SERVER_HANDLERS = window.MAIN_SERVER_HANDLERS || {};
        window.MAIN_SERVER_HANDLERS['activity.getActivityBrief'] = handleGetActivityBrief;

        LOG.success('Handler registered: activity.getActivityBrief');
    }

    // Auto-register
    if (typeof window !== 'undefined') {
        register();
    } else {
        var _check = setInterval(function() {
            if (typeof window !== 'undefined') {
                clearInterval(_check);
                register();
            }
        }, 50);
        setTimeout(function() { clearInterval(_check); }, 10000);
    }

})(window);
