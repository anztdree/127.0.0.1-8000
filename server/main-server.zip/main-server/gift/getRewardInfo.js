/**
 * ============================================================
 * GETREWARDINFO.JS - Mock Handler for gift.getRewardInfo
 * ============================================================
 *
 * Purpose: Returns all gift/welfare data for the player
 * Called when user opens the Welfare/Rewards panel
 *
 * HAR Reference: 2 calls in HAR session, identical response
 *   Response wrapper: _info object containing all gift state
 *
 * CRITICAL FIX:
 *   - HAR data is MISSING "_levelBuyGift" field
 *   - Hakim (setGiftInfo) loops: for(n in e._levelBuyGift) → setLevelBuyGiftItem(n)
 *   - Without _levelBuyGift: e._levelBuyGift[n] = undefined → undefined._id → CRASH
 *   - Fix: add "_levelBuyGift": {} (empty = no buyable level gifts)
 *
 * Pattern: Echo loop for request fields, HAR data for _info
 *
 * Author: Local SDK Bridge
 * Version: 1.0.0
 * ============================================================
 */

(function(window) {
    'use strict';

    var LOG = {
        prefix: '\uD83C\uDF81 [GIFT]',
        _log: function(level, icon, message, data) {
            var timestamp = new Date().toISOString().substr(11, 12);
            var styles = {
                success: 'color: #22c55e; font-weight: bold;',
                info: 'color: #6b7280;',
                warn: 'color: #f59e0b; font-weight: bold;',
                error: 'color: #ef4444; font-weight: bold;'
            };
            var style = styles[level] || styles.info;
            var format = '%c' + this.prefix + ' ' + icon + ' [' + timestamp + '] ' + message;
            if (data !== undefined) {
                console.log(format + ' %o', style, data);
            } else {
                console.log(format, style);
            }
        },
        success: function(msg, data) { this._log('success', '\u2705', msg, data); },
        info: function(msg, data) { this._log('info', '\u2139\uFE0F', msg, data); },
        warn: function(msg, data) { this._log('warn', '\u26A0\uFE0F', msg, data); },
        error: function(msg, data) { this._log('error', '\u274C', msg, data); }
    };

    // ========================================================
    // HAR SOURCE DATA (gift.getRewardInfo — from HAR capture)
    // ========================================================
    // File: har_all_handlers_decoded.json line 30778
    // Count: 2 calls, identical response
    //
    // NOTE: Original HAR is MISSING "_levelBuyGift" field.
    // Hakim crashes without it (see CRITICAL FIX above).
    // We add it as empty object to match Hakim's expectation.
    // ========================================================

    var HAR_INFO = {
        "_id": "7fc36b98-61da-4f14-9eab-5ed05646ac0c",
        "_isBuyFund": false,
        "_levelGiftCount": {},
        "_levelBuyGift": {},
        "_fundGiftCount": {},
        "_fristRecharge": {
            "_canGetReward": false,
            "_haveGotReward": false
        },
        "_haveGotVipRewrd": {},
        "_buyVipGiftCount": {},
        "_onlineGift": {
            "_curId": 1,
            "_nextTime": 1775056142454
        },
        "_gotChannelWeeklyRewardTag": "",
        "_clickHonghuUrlTime": 0,
        "_gotBSAddToHomeReward": false
    };

    /**
     * Builds the getRewardInfo response.
     * Echo loop: request fields → response fields (HAR pattern).
     * Then append _info from HAR data.
     */
    function buildResponse(request) {
        var response = {};

        // --- Echo loop: mirror request fields that HAR echoes back ---
        response.type = request.type;
        response.action = request.action;
        response.userId = request.userId;
        response.version = request.version;

        // --- _info: full gift/welfare state (HAR data + fix) ---
        // Clone HAR_INFO to avoid mutation
        var info = JSON.parse(JSON.stringify(HAR_INFO));

        // Override _id with current userId (echo principle)
        info._id = request.userId;

        response._info = info;

        return response;
    }

    // ========================================================
    // HANDLER REGISTRATION
    // ========================================================

    function getRewardInfoHandler(request, callback) {
        LOG.info('getRewardInfo called', request);

        var response;

        try {
            response = buildResponse(request);
            LOG.success('Response built', { keys: Object.keys(response), hasInfo: !!response._info, hasId: !!(response._info && response._info._id) });
        } catch (err) {
            LOG.error('Failed to build response: ' + err.message, err.stack);
            callback({
                type: 'gift',
                action: 'getRewardInfo',
                userId: request.userId,
                version: request.version,
                error: true,
                message: err.message
            });
            return;
        }

        LOG.info('Returning response with _info fields: ' + Object.keys(response._info).join(', '));
        callback(response);
    }

    // Expose
    window.giftHandlers = window.giftHandlers || {};
    window.giftHandlers.getRewardInfo = getRewardInfoHandler;

    LOG.success('getRewardInfo handler loaded');
    LOG.info('Fields in _info: ' + Object.keys(HAR_INFO).join(', '));
    LOG.warn('FIX: Added _levelBuyGift:{} (missing from HAR, required by Hakim setGiftInfo loop)');

})(window);
