/**
 * ============================================================
 * HANGUPSTARTGENERAL.JS - Mock Handler for hangup.startGeneral
 * ============================================================
 * 
 * Purpose: Starts a PvE battle for a lesson/stage (hangup mode)
 * Generates enemy team data based on lesson config
 * Returns player team + enemy team + battle ID for client to run battle
 * 
 * HAR Reference: s398-zd.pksilo.com_2026_04_01_22_14_53.har (Entry #840)
 * Config Files: lesson.json (enemy list, levels, difficulty, power)
 * 
 * HAR Data (Entry #840, uncompressed):
 *   Request:  {type:"hangup", action:"startGeneral", userId, team:[{heroId}...], 
 *              super:[...], battleField:20}
 *   Response: {type:"hangup", action:"startGeneral", userId, version,
 *              team, super, battleField:20,
 *              _rightTeam:{pos:{_heroDisplayId, _heroLevel, _heroStar, _skills, _attrs}},
 *              _rightSuper:[], _battleId:"<uuid>"}
 * 
 * Client processing (from main.min_777039fc.js):
 *   ts.processHandler({type:"hangup", action:"startGeneral", team, super, battleField:LESSON}, 
 *     function(r) {
 *       UserInfoSingleton.battleId = r._battleId;
 *       RunSceneWithBattle.battleWithPVEAndTeamAndOnHookBattle(
 *         team, super, callback, context, r._rightTeam, r._rightSuper, isBoss)
 *     })
 * 
 * lesson.json structure (for current lesson):
 *   enemyList: ",,55202,55105,55201"  (comma-separated hero IDs, empty=none)
 *   enemyLevel: ",,12,12,12"           (comma-separated levels)
 *   difficultyHp: "0.58,0.58,0.58,0.812,0.58"
 *   difficultyAttack: "1.68,1.68,1.68,2.016,1.68"
 *   difficultyArmor: "1,1,1,1,1"
 *   power: 16000
 *   isBoss: 4 (position of boss, 0=none)
 *   idleReward1-4: reward item IDs for idle gain
 *   rewardNum1-4: reward per second
 * 
 * Author: Local SDK Bridge
 * Version: 1.0.0
 * ============================================================
 */

(function(window) {
    'use strict';

    var LOG = {
        prefix: '[HANGUP-START]',
        _log: function(level, icon, message, data) {
            var timestamp = new Date().toISOString().substr(11, 12);
            var styles = {
                success: 'color: #22c55e; font-weight: bold;',
                info: 'color: #6b7280;',
                warn: 'color: #f59e0b; font-weight: bold;',
                error: 'color: #ef4444; font-weight: bold;'
            };
            var style = styles[level] || styles.info;
            var format = '%c' + this.prefix + ' ' + icon + ' [' + timestamp + '] ' + message;
            if (data !== undefined) {
                console.log(format + ' %o', style, data);
            } else {
                console.log(format, style);
            }
        },
        success: function(msg, data) { this._log('success', 'OK', msg, data); },
        info: function(msg, data) { this._log('info', '>>', msg, data); },
        warn: function(msg, data) { this._log('warn', '!!', msg, data); },
        error: function(msg, data) { this._log('error', 'XX', msg, data); }
    };

    // Config cache
    var lessonCache = null;
    var heroCache = null;
    var heroTypeParamCache = null;
    var heroLevelAttrCache = null;

    function loadConfigs() {
        var basePath = window.__GAME_BASE_PATH__ || '';

        fetch(basePath + 'resource/json/lesson.json').then(function(r) { return r.json(); })
            .then(function(data) {
                lessonCache = data;
                LOG.info('Loaded: lesson (' + Object.keys(data).length + ' entries)');
            })
            .catch(function(e) { LOG.warn('Failed: lesson.json — ' + e.message); });

        fetch(basePath + 'resource/json/hero.json').then(function(r) { return r.json(); })
            .then(function(data) {
                heroCache = {};
                var arr = Array.isArray(data) ? data : Object.values(data);
                arr.forEach(function(h) { heroCache[h.id] = h; });
                LOG.info('Loaded: hero');
            })
            .catch(function(e) { LOG.warn('Failed: hero.json — ' + e.message); });

        fetch(basePath + 'resource/json/heroTypeParam.json').then(function(r) { return r.json(); })
            .then(function(data) { heroTypeParamCache = data; })
            .catch(function(e) {});

        fetch(basePath + 'resource/json/heroLevelAttr.json').then(function(r) { return r.json(); })
            .then(function(data) { heroLevelAttrCache = data; })
            .catch(function(e) {});
    }

    /**
     * Generate a UUID v4
     */
    function generateBattleId() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0;
            var v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    /**
     * Build enemy hero attrs based on level and difficulty
     */
    function buildEnemyAttrs(heroDisplayId, level, diffHp, diffAtk, diffArmor) {
        var heroInfo = heroCache ? heroCache[heroDisplayId] : null;
        var typeParam = heroTypeParamCache ? heroTypeParamCache[heroInfo ? heroInfo.heroType : 'body'] : null;
        var levelData = heroLevelAttrCache ? heroLevelAttrCache[String(level)] : null;

        var baseHP = 1000, baseATK = 80, baseDEF = 100, spd = 300;

        if (levelData && heroInfo && typeParam) {
            baseHP  = levelData.hp    * typeParam.hpParam    + (typeParam.hpBais || 0);
            baseATK = levelData.attack * typeParam.attackParam + (typeParam.attackBais || 0);
            baseDEF = levelData.armor  * typeParam.armorParam  + (typeParam.armorBais || 0);
            spd = heroInfo.speed || 300;
        }

        // Apply difficulty multipliers
        baseHP  = baseHP  * diffHp;
        baseATK = baseATK * diffAtk;
        baseDEF = baseDEF * diffArmor;

        // Build attr items (exact key set from HAR: 29 attr IDs)
        // HAR IDs: 0-16, 21-26, 28-29, 31, 36-37, 41
        var items = {};
        items['0']  = { _id: 0,  _num: baseHP };    // HP
        items['1']  = { _id: 1,  _num: baseATK };   // ATK
        items['2']  = { _id: 2,  _num: baseDEF };   // DEF
        items['3']  = { _id: 3,  _num: spd };       // SPD
        for (var i = 4; i <= 15; i++) items[String(i)] = { _id: i, _num: 0 };
        items['16'] = { _id: 16, _num: 50 };        // Energy
        items['21'] = { _id: 21, _num: Math.floor(baseHP + baseATK * 10 + baseDEF * 2) }; // Power
        items['22'] = { _id: 22, _num: baseHP };    // MaxHP
        // HAR: 23-26 (continuous zeros)
        for (var j = 23; j <= 26; j++) items[String(j)] = { _id: j, _num: 0 };
        // HAR: 28-29
        items['28'] = { _id: 28, _num: 0 };
        items['29'] = { _id: 29, _num: 0 };
        // HAR: 31
        items['31'] = { _id: 31, _num: 0 };
        // HAR: 36-37
        items['36'] = { _id: 36, _num: 0 };
        items['37'] = { _id: 37, _num: 0 };
        // HAR: 41 = 100 (hero power bonus)
        items['41'] = { _id: 41, _num: 100 };

        return { _items: items };
    }

    /**
     * Get enemy skills for a hero display ID
     */
    function buildEnemySkills(heroDisplayId) {
        var heroInfo = heroCache ? heroCache[heroDisplayId] : null;
        if (!heroInfo) return {};

        var skills = {};
        // Add normal skill (passive = type 0)
        if (heroInfo.skill) {
            skills[String(heroInfo.skill)] = { _type: 0, _id: heroInfo.skill, _level: 1 };
        }
        // Add active skill (active = type 1)
        if (heroInfo.normal) {
            skills[String(heroInfo.normal)] = { _type: 1, _id: heroInfo.normal, _level: 1 };
        }
        // Add passive skills
        if (heroInfo.skillPassive1) {
            skills[String(heroInfo.skillPassive1)] = { _type: 0, _id: heroInfo.skillPassive1, _level: 1 };
        }

        return skills;
    }

    // ========================================================
    // MAIN HANDLER
    // ========================================================

    function handleStartGeneral(request, playerData) {
        LOG.info('Handling hangup.startGeneral');

        var hangup = playerData.hangup || {};
        var curLess = hangup._curLess || 10101;

        LOG.info('Current lesson: ' + curLess);

        // Get lesson config
        var lesson = lessonCache ? lessonCache[String(curLess)] : null;
        if (!lesson) {
            LOG.warn('Lesson ' + curLess + ' not found, using defaults');
            lesson = {
                enemyList: ',,55201,55202,55203',
                enemyLevel: ',,8,8,8',
                difficultyHp: '1,1,1,1,1',
                difficultyAttack: '1,1,1,1,1',
                difficultyArmor: '1,1,1,1,1',
                power: 5000
            };
        }

        // Parse enemy config
        var enemyIds = (lesson.enemyList || '').split(',');
        var enemyLevels = (lesson.enemyLevel || '').split(',');
        var diffHp = (lesson.difficultyHp || '1,1,1,1,1').split(',');
        var diffAtk = (lesson.difficultyAttack || '1,1,1,1,1').split(',');
        var diffArmor = (lesson.difficultyArmor || '1,1,1,1,1').split(',');

        // Build _rightTeam (enemy team)
        // Positions are keyed by number (0-4), only non-empty slots
        var rightTeam = {};
        for (var pos = 0; pos < enemyIds.length && pos < 5; pos++) {
            var eid = enemyIds[pos].trim();
            if (!eid) continue; // Skip empty positions

            var eLevel = parseInt(enemyLevels[pos]) || 1;
            var eHpMult = parseFloat(diffHp[pos]) || 1;
            var eAtkMult = parseFloat(diffAtk[pos]) || 1;
            var eArmorMult = parseFloat(diffArmor[pos]) || 1;

            rightTeam[String(pos)] = {
                _heroDisplayId: parseInt(eid),
                _heroLevel: eLevel,
                _heroStar: 0,
                _skills: buildEnemySkills(parseInt(eid)),
                _attrs: buildEnemyAttrs(parseInt(eid), eLevel, eHpMult, eAtkMult, eArmorMult),
                _skinId: 0,
                _weaponHaloId: 0,
                _weaponHaloLevel: 0
            };
        }

        // If no enemies from config, generate at least 1
        if (Object.keys(rightTeam).length === 0) {
            rightTeam['3'] = {
                _heroDisplayId: 55202,
                _heroLevel: 1,
                _heroStar: 0,
                _skills: buildEnemySkills(55202),
                _attrs: buildEnemyAttrs(55202, 1, 1, 1, 1),
                _skinId: 0,
                _weaponHaloId: 0,
                _weaponHaloLevel: 0
            };
        }

        LOG.info('Enemy team: ' + Object.keys(rightTeam).length + ' heroes');

        // Build response (matches HAR format)
        var responseData = {
            type: 'hangup',
            action: 'startGeneral',
            userId: request.userId,
            version: request.version || '1.0',
            team: request.team || [],
            super: request.super || [],
            battleField: request.battleField || 20,
            _rightTeam: rightTeam,
            _rightSuper: [],
            _battleId: generateBattleId()
        };

        LOG.success('startGeneral → battle ' + responseData._battleId.substring(0, 8) + '...');

        return responseData;
    }

    // ========================================================
    // REGISTER HANDLER
    // ========================================================
    function register() {
        if (typeof window === 'undefined') {
            console.error('[HANGUP-START] window not available');
            return;
        }

        window.MAIN_SERVER_HANDLERS = window.MAIN_SERVER_HANDLERS || {};
        window.MAIN_SERVER_HANDLERS['hangup.startGeneral'] = handleStartGeneral;

        LOG.success('Handler registered: hangup.startGeneral');
        loadConfigs();
    }

    if (typeof window !== 'undefined') {
        register();
    } else {
        var _check = setInterval(function() {
            if (typeof window !== 'undefined') {
                clearInterval(_check);
                register();
            }
        }, 50);
        setTimeout(function() { clearInterval(_check); }, 10000);
    }

})(window);
