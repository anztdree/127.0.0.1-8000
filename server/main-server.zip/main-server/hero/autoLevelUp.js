/**
 * ============================================================
 * HEROAUTOLEVELUP.JS - Mock Handler for hero.autoLevelUp  v3.0.0
 * ============================================================
 * 
 * Purpose: Levels up a hero, consuming Exp Capsules (131) and Gold (102)
 * Stops at tier boundaries (every 20 levels) — hero must evolve to continue
 * 
 * HAR Reference: har_all_handlers_decoded.json → hero.autoLevelUp (30 entries)
 * Hakim Reference: main.min_777039fc.js → HerosManager.levelUpCallBack / setTotalAttrs / setBaseAttr
 * 
 * Config Files:
 *   - heroLevelUp{White,Green,Blue,Purple,Orange,FlickerOrange}.json (cost per level)
 *   - heroLevelUpMul.json (quality → config file name)
 *   - heroLevelAttr.json (base HP/ATK/DEF per level)
 *   - hero.json (hero display data: heroType, talent, speed, balancePower)
 *   - heroTypeParam.json (type → HP/ATK/DEF multiplier + bias)
 *   - heroPower.json (type+attrName → powerParam, powerExtraParam)
 *   - abilityName.json (attrId → englishName)
 * 
 * === HAKIM CLIENT PROCESSING FLOW (CRITICAL) ===
 * 
 *   1. ts.processHandler({type:"hero", action:"autoLevelUp", ...})
 *   2. Callback → HerosManager.levelUpCallBack(response, hero)
 *      → setHeroLevelUpDataChange(response, hero)
 *         → if response._evolveLevel → sets heroBaseAttr.evolveLevel
 *         → if response._heroLevel → sets heroBaseAttr.level
 *      → setTotalAttrs(response, hero)
 *         → setBaseAttr(response._baseAttr, hero)
 *            → for each item in _baseAttr._items:
 *               if abilityName[id] exists → heroBaseAttr[englishName] = _num
 *            → heroBaseAttr.hp *= heroBaseAttr.talent    ← MULTIPLIED CLIENT-SIDE
 *            → heroBaseAttr.attack *= heroBaseAttr.talent ← MULTIPLIED CLIENT-SIDE
 *         → for each item in _totalAttr._items:
 *               totalAttr[id] = {id, num}                 ← READ DIRECTLY, NO TRANSFORM
 *               if id==21 → heroBaseAttr.power = Math.floor(_num)
 *      → setTotalCost(response, hero) → deserializes cost history
 *      → ItemsCommonSingleton.resetTtemsCallBack(response) → updates item counts
 * 
 *   KEY INSIGHT: _baseAttr = RAW values (client multiplies hp/atk by talent)
 *               _totalAttr = FINAL values (client reads directly, NO transform)
 *               For no-equipment hero: _totalAttr.hp = _baseAttr.hp * talent
 *               For real server: _totalAttr.hp = _baseAttr.hp * talent + equipmentBonus
 * 
 * Response fields (echo from request):
 *   - type, action, userId, heroId, version, times
 * 
 * Response fields (calculated):
 *   - _heroLevel: new level number
 *   - _totalAttr: { _items: { "0":{_id:0,_num:totalHP}, ... } } — FINAL battle stats (key 0-41)
 *   - _baseAttr: { _items: { "0":{_id:0,_num:rawHP}, ... } } — RAW stats (keys 0-15, 23-41, skip 16-22)
 *   - _totalCost: cumulative cost per category (7 categories)
 *   - _changeInfo: { _items: { "102":{remainingGold}, "131":{remainingExpCapsule} } }
 *   - _linkHeroesTotalAttr: {} (empty)
 *   - _linkHeroesBasicAttr: {} (empty)
 * 
 * Power Calculation (server-side, v3.0.0):
 *   Uses heroPower.json entries for heroType:
 *     for each entry matching heroType:
 *       power += totalAttr[attrId] * powerParam
 *       if powerExtraParam exists:
 *         power += totalAttr[26] * powerExtraParam  (extraArmor bonus)
 *   Final: power = Math.floor(power * balancePower)
 *   balancePower comes from hero.json per-hero field
 * 
 * v3.0.0 Changes:
 *   - FIX: Power now uses heroPower.json weights + balancePower (was hardcoded)
 *   - FIX: _baseAttr levelCap now uses qualityId * 20 (was hardcoded 100)
 *   - FIX: Removed all banned `|| default` patterns
 *   - FIX: version/times echoed directly without defaults
 *   - NOTE: Stat formula verified — _totalAttr.hp = _baseAttr.hp * talent (correct per Hakim)
 *   - LIMITATION: Awaken/star bonuses not tracked (raw talent from hero.json used)
 *
 * Author: Local SDK Bridge
 * ============================================================
 */

(function(window) {
    'use strict';

    var LOG = {
        prefix: '[HERO-AUTO-LEVELUP]',
        _log: function(level, icon, message, data) {
            var timestamp = new Date().toISOString().substr(11, 12);
            var styles = {
                success: 'color: #22c55e; font-weight: bold;',
                info: 'color: #6b7280;',
                warn: 'color: #f59e0b; font-weight: bold;',
                error: 'color: #ef4444; font-weight: bold;'
            };
            var style = styles[level] || styles.info;
            var format = '%c' + this.prefix + ' ' + icon + ' [' + timestamp + '] ' + message;
            if (data !== undefined) {
                console.log(format + ' %o', style, data);
            } else {
                console.log(format, style);
            }
        },
        success: function(msg, data) { this._log('success', 'OK', msg, data); },
        info: function(msg, data) { this._log('info', '>>', msg, data); },
        warn: function(msg, data) { this._log('warn', '!!', msg, data); },
        error: function(msg, data) { this._log('error', 'XX', msg, data); }
    };

    // ========================================================
    // ATTR NAME → ID MAPPING (from Hakim HeroAbilityName enum)
    // ========================================================
    var ATTR_NAME_TO_ID = {
        'hp': 0, 'attack': 1, 'armor': 2, 'speed': 3,
        'hit': 4, 'dodge': 5, 'block': 6, 'blockEffect': 7,
        'skillDamage': 8, 'critical': 9, 'criticalResist': 10,
        'criticalDamage': 11, 'armorBreak': 12, 'damageReduce': 13,
        'controlResist': 14, 'trueDamage': 15, 'energy': 16,
        'hpPercent': 17, 'armorPercent': 18, 'attackPercent': 19,
        'speedPercent': 20, 'power': 21, 'orghp': 22,
        'superDamage': 23, 'healPlus': 24, 'healerPlus': 25,
        'extraArmor': 26, 'shielderPlus': 27, 'damageUp': 28,
        'damageDown': 29, 'talent': 30, 'superDamageResist': 31,
        'dragonBallWarDamageUp': 32, 'dragonBallWarDamageDown': 33,
        'bloodDamage': 34, 'normalAttack': 35, 'criticalDamageResist': 36,
        'blockThrough': 37
    };

    // ========================================================
    // CONFIG CACHES
    // ========================================================
    var QUALITY_CONFIG_MAP = {
        1: 'heroLevelUpWhite',
        2: 'heroLevelUpGreen',
        3: 'heroLevelUpBlue',
        4: 'heroLevelUpPurple',
        5: 'heroLevelUpOrange',
        6: 'heroLevelUpFlickerOrange'
    };

    var COST_EXP_CAPSULE = 131;
    var COST_GOLD = 102;

    var configCache = {};
    var heroLevelAttrCache = null;
    var heroConfigCache = null;
    var heroTypeParamCache = null;
    var heroPowerCache = null;
    var configsReady = false;

    // ========================================================
    // CONFIG LOADER
    // ========================================================
    function loadConfigs() {
        var configNames = Object.values(QUALITY_CONFIG_MAP);
        var basePath = window.__GAME_BASE_PATH__ || '';
        var allPromises = [];

        LOG.info('Loading configs...');

        // Level-up cost configs
        configNames.forEach(function(name) {
            var url = basePath + 'resource/json/' + name + '.json';
            allPromises.push(
                fetch(url).then(function(r) { return r.json(); })
                    .then(function(data) {
                        configCache[name] = data;
                        LOG.info('Loaded: ' + name);
                    })
                    .catch(function(err) {
                        LOG.warn('Failed: ' + name + ' — ' + err.message);
                        configCache[name] = {};
                    })
            );
        });

        // heroLevelAttr.json — base stats per level
        allPromises.push(
            fetch(basePath + 'resource/json/heroLevelAttr.json').then(function(r) { return r.json(); })
                .then(function(data) {
                    heroLevelAttrCache = data;
                    LOG.info('Loaded: heroLevelAttr (' + Object.keys(data).length + ' levels)');
                })
                .catch(function(err) { LOG.warn('Failed: heroLevelAttr — ' + err.message); })
        );

        // hero.json — hero display data
        allPromises.push(
            fetch(basePath + 'resource/json/hero.json').then(function(r) { return r.json(); })
                .then(function(data) {
                    heroConfigCache = {};
                    if (Array.isArray(data)) {
                        data.forEach(function(h) { heroConfigCache[h.id] = h; });
                    } else {
                        for (var k in data) { heroConfigCache[data[k].id] = data[k]; }
                    }
                    LOG.info('Loaded: hero (' + Object.keys(heroConfigCache).length + ' heroes)');
                })
                .catch(function(err) { LOG.warn('Failed: hero.json — ' + err.message); })
        );

        // heroTypeParam.json — type stat multipliers
        allPromises.push(
            fetch(basePath + 'resource/json/heroTypeParam.json').then(function(r) { return r.json(); })
                .then(function(data) {
                    heroTypeParamCache = data;
                    LOG.info('Loaded: heroTypeParam');
                })
                .catch(function(err) { LOG.warn('Failed: heroTypeParam — ' + err.message); })
        );

        // heroPower.json — power calculation params (server-side)
        allPromises.push(
            fetch(basePath + 'resource/json/heroPower.json').then(function(r) { return r.json(); })
                .then(function(data) {
                    heroPowerCache = data;
                    LOG.info('Loaded: heroPower (' + Object.keys(data).length + ' entries)');
                })
                .catch(function(err) { LOG.warn('Failed: heroPower — ' + err.message); })
        );

        return Promise.all(allPromises).then(function() {
            configsReady = true;
            LOG.success('All configs loaded');
        });
    }

    // ========================================================
    // PLAYER ITEM HELPERS
    // ========================================================
    function getItemCount(playerData, itemId) {
        var items = playerData.items;
        var item = items[String(itemId)];
        return item ? (item._num) : 0;
    }

    function deductItem(playerData, itemId, amount) {
        var items = playerData.items;
        var key = String(itemId);
        var item = items[key];
        if (!item) {
            items[key] = { _id: itemId, _num: 0 };
            item = items[key];
        }
        var current = item._num;
        if (current < amount) return false;
        item._num = current - amount;
        return true;
    }

    // ========================================================
    // STAT CALCULATION
    // ========================================================

    /**
     * Calculate _baseAttr for a hero at a given level.
     * _baseAttr = RAW values — Hakim multiplies hp/atk by talent CLIENT-SIDE.
     * 
     * Keys: 0-15 (all stats), skip 16-22 (per HAR behavior), 23-41
     * 
     * Formula (from config files):
     *   baseHP  = heroLevelAttr[level].hp   * typeParam.hpParam    + typeParam.hpBais
     *   baseATK = heroLevelAttr[level].attack * typeParam.attackParam + typeParam.attackBais
     *   baseDEF = heroLevelAttr[level].armor  * typeParam.armorParam  + typeParam.armorBais
     *   baseSPD = hero.json[displayId].speed
     *   talent   = hero.json[displayId].talent   (raw, before awaken bonus)
     *   levelCap = qualityId * 20   (qualityId = Math.ceil(level / 20))
     * 
     * LIMITATION: Awaken/star bonuses not included (would modify talent and stats).
     * Real server tracks these per-hero. Mock uses raw hero.json talent.
     */
    function calcBaseAttr(displayId, level) {
        var levelData = heroLevelAttrCache ? heroLevelAttrCache[String(level)] : null;
        var heroInfo = heroConfigCache ? heroConfigCache[displayId] : null;
        var typeParam = heroInfo ? (heroTypeParamCache ? heroTypeParamCache[heroInfo.heroType] : null) : null;

        if (!levelData || !heroInfo || !typeParam) {
            LOG.error('Missing config: displayId=' + displayId + ' level=' + level);
            return { _items: {} };
        }

        var hp  = levelData.hp    * typeParam.hpParam    + typeParam.hpBais;
        var atk = levelData.attack * typeParam.attackParam + typeParam.attackBais;
        var def = levelData.armor  * typeParam.armorParam  + typeParam.armorBais;
        var spd = heroInfo.speed;
        var talent = heroInfo.talent;
        var qualityId = Math.ceil(level / 20);

        var items = {};

        // Keys 0-15: all base attributes
        for (var i = 0; i <= 15; i++) {
            var num = 0;
            if (i === 0) num = hp;
            else if (i === 1) num = atk;
            else if (i === 2) num = def;
            else if (i === 3) num = spd;
            items[String(i)] = { _id: i, _num: num };
        }

        // SKIP 16-22 (HAR behavior: _baseAttr does NOT include these keys)
        // 16=energy, 17=hpPercent, 18=armorPercent, 19=attackPercent, 20=speedPercent
        // 21=power, 22=orghp — these only appear in _totalAttr

        // Keys 23-41: extended attributes
        for (var j = 23; j <= 41; j++) {
            var num2 = 0;
            if (j === 30) num2 = talent;              // CritDmgRate (raw talent)
            else if (j === 41) num2 = qualityId * 20;  // LevelCap (FIX: was hardcoded 100)
            items[String(j)] = { _id: j, _num: num2 };
        }

        return { _items: items };
    }

    /**
     * Calculate Power from _totalAttr values using heroPower.json.
     * This is a SERVER-SIDE calculation — Hakim does NOT recalculate power.
     * Client just reads _totalAttr[21]._num directly.
     * 
     * Formula:
     *   for each heroPower entry matching heroType:
     *     power += totalAttr[attrId] * powerParam
     *     if entry has powerExtraParam:
     *       power += totalAttr[26] * powerExtraParam   (extraArmor bonus)
     *   power = Math.floor(power * balancePower)
     * 
     * heroPower.json has 403 entries (13 heroType × 31 attrs per type).
     * Each entry: { id, heroType, attName, powerParam, [powerExtraParam] }
     */
    function calcPower(heroType, totalAttrItems, balancePower) {
        if (!heroPowerCache) {
            LOG.warn('heroPower.json not loaded, power will be 0');
            return 0;
        }

        var power = 0;
        var extraArmorValue = 0;
        var extraItem = totalAttrItems['26']; // extraArmor
        if (extraItem) {
            extraArmorValue = extraItem._num;
        }

        for (var key in heroPowerCache) {
            var entry = heroPowerCache[key];
            if (entry.heroType !== heroType) continue;

            var attrId = ATTR_NAME_TO_ID[entry.attName];
            if (attrId === undefined) continue;

            var attrItem = totalAttrItems[String(attrId)];
            if (attrItem) {
                power += attrItem._num * entry.powerParam;
            }

            // powerExtraParam: extra power contribution from extraArmor
            if (entry.powerExtraParam && extraArmorValue) {
                power += extraArmorValue * entry.powerExtraParam;
            }
        }

        return Math.floor(power * balancePower);
    }

    /**
     * Calculate _totalAttr for a hero at a given level.
     * _totalAttr = FINAL battle stats — Hakim reads directly, NO transform.
     * 
     * For no-equipment hero:
     *   totalHP  = baseHP * talent     (Hakim: heroBaseAttr.hp = _baseAttr.hp * talent)
     *   totalATK = baseATK * talent    (Hakim: heroBaseAttr.attack = _baseAttr.attack * talent)
     *   totalDEF = baseDEF             (NOT multiplied by talent — verified from HAR)
     *   totalSPD = baseSPD             (NOT multiplied by talent)
     *   orghp    = totalHP             (same as totalHP — verified from HAR)
     *   energy   = 50                  (fixed — verified from HAR)
     *   power    = calcPower(...)      (from heroPower.json × balancePower)
     *   levelCap = qualityId * 20
     * 
     * Keys: ALL 0-41 (unlike _baseAttr which skips 16-22)
     */
    function calcTotalAttr(displayId, level) {
        var baseAttr = calcBaseAttr(displayId, level);
        var baseItems = baseAttr._items;

        if (!baseItems || Object.keys(baseItems).length === 0) {
            LOG.error('calcBaseAttr returned empty for displayId=' + displayId + ' level=' + level);
            return { _items: {} };
        }

        var heroInfo = heroConfigCache[displayId];
        if (!heroInfo) {
            LOG.error('Hero info missing: ' + displayId);
            return { _items: {} };
        }

        var heroType = heroInfo.heroType;
        var balancePower = heroInfo.balancePower;

        var hp  = baseItems['0']._num;
        var atk = baseItems['1']._num;
        var def = baseItems['2']._num;
        var spd = baseItems['3']._num;
        var talent = baseItems['30']._num;
        var qualityId = Math.ceil(level / 20);

        // Talent-scaled values for _totalAttr
        var totalHP  = hp * talent;
        var totalATK = atk * talent;
        // totalDEF = def (NOT scaled)
        // totalSPD = spd (NOT scaled)

        var items = {};

        // Keys 0-15: final battle stats
        for (var i = 0; i <= 15; i++) {
            var num = 0;
            if (i === 0) num = totalHP;
            else if (i === 1) num = totalATK;
            else if (i === 2) num = def;
            else if (i === 3) num = spd;
            items[String(i)] = { _id: i, _num: num };
        }

        // Keys 16-22: extended stats (ONLY in _totalAttr, not in _baseAttr)
        items['16'] = { _id: 16, _num: 50 };          // Energy (fixed)
        items['17'] = { _id: 17, _num: 0 };           // hpPercent
        items['18'] = { _id: 18, _num: 0 };           // armorPercent
        items['19'] = { _id: 19, _num: 0 };           // attackPercent
        items['20'] = { _id: 20, _num: 0 };           // speedPercent
        // Key 21 (power): calculated below after all other attrs are set
        items['22'] = { _id: 22, _num: totalHP };      // orghp = totalHP (HAR verified)

        // Keys 23-41
        for (var j = 23; j <= 41; j++) {
            var num2 = 0;
            if (j === 30) num2 = talent;
            else if (j === 41) num2 = qualityId * 20;  // LevelCap
            items[String(j)] = { _id: j, _num: num2 };
        }

        // Calculate power using heroPower.json + balancePower
        var power = calcPower(heroType, items, balancePower);
        items['21'] = { _id: 21, _num: power };

        return { _items: items };
    }

    // ========================================================
    // RESPONSE BUILDERS
    // ========================================================

    /**
     * Build _totalCost for response.
     * Structure from HAR: tracks cumulative cost per category.
     * _levelUp contains current session's gold/exp capsule cost.
     */
    function buildTotalCost(costGold, costExp) {
        return {
            _wakeUp:    { _items: {} },
            _earring:   { _items: {} },
            _levelUp:   {
                _items: {
                    "102": { _id: 102, _num: costGold },
                    "131": { _id: 131, _num: costExp }
                }
            },
            _evolve:    { _items: {} },
            _skill:     { _items: {} },
            _qigong:    { _items: {} },
            _heroBreak: { _items: {} }
        };
    }

    /**
     * Build _changeInfo for response.
     * Contains remaining item counts after deduction.
     * Client uses via ItemsCommonSingleton.resetTtemsCallBack.
     */
    function buildChangeInfo(remainingGold, remainingExpCapsule) {
        return {
            _items: {
                "102": { _id: 102, _num: remainingGold },
                "131": { _id: 131, _num: remainingExpCapsule }
            }
        };
    }

    // ========================================================
    // MAIN HANDLER
    // ========================================================

    function handleHeroAutoLevelUp(request, playerData) {
        LOG.info('Handling hero.autoLevelUp');
        LOG.info('UserId: ' + request.userId);

        // Config readiness check
        if (!configsReady) {
            LOG.error('Configs not loaded yet');
            return { ret: 1, type: 'hero', action: 'autoLevelUp', userId: request.userId };
        }

        var heroId = request.heroId;
        var times = request.times;  // FIX: no `|| 1` — echo from client

        if (!heroId) {
            LOG.error('Missing heroId');
            return { ret: 1, type: 'hero', action: 'autoLevelUp', userId: request.userId };
        }

        if (!times || times <= 0) {
            LOG.error('Missing or invalid times: ' + times);
            return { ret: 1, type: 'hero', action: 'autoLevelUp', userId: request.userId };
        }

        // --- Get hero data ---
        var heros = playerData.heros;
        var heroData = heros[heroId];

        if (!heroData) {
            LOG.error('Hero not found: ' + heroId);
            return { ret: 1, type: 'hero', action: 'autoLevelUp', userId: request.userId };
        }

        var displayId = heroData._heroDisplayId;
        if (!displayId) {
            LOG.error('Hero missing _heroDisplayId: ' + heroId);
            return { ret: 1, type: 'hero', action: 'autoLevelUp', userId: request.userId };
        }

        var heroBaseAttr = heroData._heroBaseAttr;
        var currentLevel = heroBaseAttr._level;

        if (!currentLevel) {
            LOG.error('Hero missing _level: ' + heroId);
            return { ret: 1, type: 'hero', action: 'autoLevelUp', userId: request.userId };
        }

        LOG.info('displayId=' + displayId + ' level=' + currentLevel + ' times=' + times);

        // --- Calculate quality tier and max level ---
        var qualityId = Math.ceil(currentLevel / 20);
        var maxLevel = qualityId * 20;

        if (currentLevel >= maxLevel) {
            LOG.warn('At max level ' + currentLevel + ' for tier ' + qualityId);
            return buildResponse(request, heroId, displayId, currentLevel, 0, 0, 0,
                                 getItemCount(playerData, COST_GOLD),
                                 getItemCount(playerData, COST_EXP_CAPSULE));
        }

        // --- Determine target level ---
        var targetLevel = Math.min(currentLevel + times, maxLevel);
        var actualTimes = targetLevel - currentLevel;

        if (actualTimes <= 0) {
            return buildResponse(request, heroId, displayId, currentLevel, 0, 0, 0,
                                 getItemCount(playerData, COST_GOLD),
                                 getItemCount(playerData, COST_EXP_CAPSULE));
        }

        // --- Get level-up cost config ---
        var configName = QUALITY_CONFIG_MAP[qualityId];
        if (!configName) {
            LOG.error('Unknown qualityId: ' + qualityId);
            return { ret: 1, type: 'hero', action: 'autoLevelUp', userId: request.userId };
        }

        var levelUpConfig = configCache[configName];
        if (!levelUpConfig) {
            LOG.error('Config not loaded: ' + configName);
            return { ret: 1, type: 'hero', action: 'autoLevelUp', userId: request.userId };
        }

        // --- Calculate total cost ---
        var totalCostExp = 0;
        var totalCostGold = 0;
        var costValid = true;

        for (var lvl = currentLevel + 1; lvl <= targetLevel; lvl++) {
            var lc = levelUpConfig[String(lvl)];
            if (!lc) {
                LOG.warn('No config for level ' + lvl + ' in ' + configName);
                targetLevel = lvl - 1;
                actualTimes = targetLevel - currentLevel;
                costValid = false;
                break;
            }
            totalCostExp += lc.num1;
            totalCostGold += lc.num2;
        }

        // Recalculate if we had to reduce target
        if (!costValid) {
            totalCostExp = 0;
            totalCostGold = 0;
            for (var lvl2 = currentLevel + 1; lvl2 <= targetLevel; lvl2++) {
                var lc2 = levelUpConfig[String(lvl2)];
                if (lc2) {
                    totalCostExp += lc2.num1;
                    totalCostGold += lc2.num2;
                }
            }
        }

        // --- Check affordability ---
        var playerExp = getItemCount(playerData, COST_EXP_CAPSULE);
        var playerGold = getItemCount(playerData, COST_GOLD);

        if (playerExp < totalCostExp || playerGold < totalCostGold) {
            // Level up as far as possible
            targetLevel = findMaxAffordableLevel(levelUpConfig, currentLevel, maxLevel, playerExp, playerGold);
            actualTimes = targetLevel - currentLevel;

            if (actualTimes <= 0) {
                LOG.warn('Cannot afford any level up');
                return buildResponse(request, heroId, displayId, currentLevel, 0, 0, 0,
                                     playerGold, playerExp);
            }

            totalCostExp = 0;
            totalCostGold = 0;
            for (var lvl3 = currentLevel + 1; lvl3 <= targetLevel; lvl3++) {
                var lc3 = levelUpConfig[String(lvl3)];
                if (lc3) {
                    totalCostExp += lc3.num1;
                    totalCostGold += lc3.num2;
                }
            }
            LOG.info('Adjusted: ' + actualTimes + ' levels');
        }

        // --- Deduct costs ---
        if (!deductItem(playerData, COST_EXP_CAPSULE, totalCostExp) ||
            !deductItem(playerData, COST_GOLD, totalCostGold)) {
            LOG.error('Failed to deduct items');
            return { ret: 1, type: 'hero', action: 'autoLevelUp', userId: request.userId };
        }

        // --- Update hero level ---
        heroData._heroBaseAttr._level = targetLevel;

        LOG.success('Level ' + currentLevel + ' -> ' + targetLevel + ' (' + actualTimes + ')');

        // --- Save playerData ---
        if (window.LOCAL_MAIN_SERVER) {
            try {
                localStorage.setItem('dragonball_player_data_' + request.userId, JSON.stringify(playerData));
                LOG.info('Saved playerData');
            } catch (e) {
                LOG.warn('Save failed: ' + e.message);
            }
        }

        // --- Build and return response ---
        var remGold = getItemCount(playerData, COST_GOLD);
        var remExp = getItemCount(playerData, COST_EXP_CAPSULE);

        var response = buildResponse(request, heroId, displayId, targetLevel, actualTimes,
                                     totalCostGold, totalCostExp, remGold, remExp);

        LOG.info('Done. Level=' + targetLevel + ' Power=' +
                 response._totalAttr._items['21']._num +
                 ' Gold=' + remGold + ' ExpCapsule=' + remExp);

        return response;
    }

    /**
     * Build the complete response matching HAR format.
     * All fields required for client processing.
     * version/times echoed directly (no defaults).
     */
    function buildResponse(request, heroId, displayId, newLevel, actualTimes,
                           costGold, costExp, remainingGold, remainingExp) {
        var totalAttr = calcTotalAttr(displayId, newLevel);
        var baseAttr = calcBaseAttr(displayId, newLevel);

        return {
            type: 'hero',
            action: 'autoLevelUp',
            userId: request.userId,
            heroId: heroId,
            version: request.version,       // FIX: echo directly, no `|| '1.0'`
            times: actualTimes,
            _totalAttr: totalAttr,
            _baseAttr: baseAttr,
            _totalCost: buildTotalCost(costGold, costExp),
            _changeInfo: buildChangeInfo(remainingGold, remainingExp),
            _heroLevel: newLevel,
            _linkHeroesTotalAttr: {},
            _linkHeroesBasicAttr: {}
        };
    }

    /**
     * Find max affordable levels.
     * No `||` defaults on cost values — if missing, stop leveling.
     */
    function findMaxAffordableLevel(levelUpConfig, currentLevel, maxLevel, availExp, availGold) {
        var affordable = currentLevel;
        for (var lvl = currentLevel + 1; lvl <= maxLevel; lvl++) {
            var cfg = levelUpConfig[String(lvl)];
            if (!cfg) break;
            var expCost = cfg.num1;
            var goldCost = cfg.num2;
            if (expCost === undefined || goldCost === undefined) {
                LOG.warn('Missing cost data for level ' + lvl);
                break;
            }
            if (availExp < expCost || availGold < goldCost) break;
            availExp -= expCost;
            availGold -= goldCost;
            affordable = lvl;
        }
        return affordable;
    }

    // ========================================================
    // REGISTER HANDLER
    // ========================================================
    function register() {
        if (typeof window === 'undefined') {
            console.error('[HERO-AUTO-LEVELUP] window not available');
            return;
        }

        window.MAIN_SERVER_HANDLERS = window.MAIN_SERVER_HANDLERS || {};
        window.MAIN_SERVER_HANDLERS['hero.autoLevelUp'] = handleHeroAutoLevelUp;

        LOG.success('Handler registered: hero.autoLevelUp (v3.0.0)');
        loadConfigs();
    }

    if (typeof window !== 'undefined') {
        register();
    } else {
        var _check = setInterval(function() {
            if (typeof window !== 'undefined') {
                clearInterval(_check);
                register();
            }
        }, 50);
        setTimeout(function() { clearInterval(_check); }, 10000);
    }

})(window);
